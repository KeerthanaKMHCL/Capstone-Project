import React from 'react'
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import axios from 'axios'

function UpdateUser() {
  const[id,setId]=useState(0);
  const[name,setName]=useState("");
  const[emailId,setEmailId]=useState("");
  const[password,setPassword]=useState("");
  const[users,setUsers]=useState([]);
  const navigate=useNavigate();


  useEffect(()=>{
    axios.get("http://localhost:8080/api/admin/owner/getAllUsers").then(res=>setUsers(res.data)).catch(err=>console.log(err));
  },[]);
  const ClickEv=(e)=>{
    e.preventDefault();
    let count=0;
    for(let i=0;i<users.length;i++){
        if(users[i].userEmail===emailId || users[i].userId===id){
            count++;
        }
    }
    if(count>0){
        axios.patch("http://localhost:8080/api/owner/user/updateUser/"+id,{
                "userName": name,
                "userPassword": password,
                "userEmail": emailId
            }
            ).then(res=>res.data).catch(err=>console.log(err));
            alert("User Successfully Updated!");
            navigate("/OwnerDashboard");
    }
    else{
          }
          alert("User does not exist...");
  }

  return (
    <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>
                <label>EmailId</label><br/>
                <input type="text" placeholder="Enter EmailId" value={emailId} onChange={(e)=>{setEmailId(e.target.value)}} required></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Update User</button>
            </form>
        </div>
  )
}

export default UpdateUser