import React, { Component } from 'react'
import axios from 'axios'

class ListAllOwners extends Component {

state = {
    owners: []
}

componentDidMount = () => {
    axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(res => {
        const owners = res.data;
        this.setState({owners});
    }).catch(err=>console.log(err));
}

  render() {
    return (
      <div>
            <ul className='ulistList'>{
                this.state.owners.map(owner =>
                                <div className='innerDiv'>
                                    <li>ID : {owner.ownerId}</li>
                                    <li>Name : {owner.ownerName}</li>
                                    <li>EmailID : {owner.ownerEmail}</li>
                                    <li>Password : {owner.ownerPassword}</li>
                                </div>
                    )}
            </ul>
      </div>
    )
  }
}

export default ListAllOwners