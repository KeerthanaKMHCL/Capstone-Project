/*
Author: Mounisha
Date: 19/01/2023
*/

import { useEffect, useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";

function RegisterUser(){
    const[id,setId]=useState(0);
    const[name,setName]=useState("");
    const[emailId,setEmailId]=useState("");
    const[password,setPassword]=useState("");
    const[users,setUsers]=useState([]);
    const navigate=useNavigate();
    
    useEffect(()=>{
        axios.get("http://localhost:8080/api/owner/user/getAllUsers").then(res=>setUsers(res.data)).catch(err=>console.log(err));
    },[]);
    const ClickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<users.length;i++){
            if(users[i].userEmail===emailId){
                count++;
            }
        }
        if(count>0){
            alert("EmailId already exists!!!");
        }
        else{
            axios.post("http://localhost:8080/api/user/register",{
                "userId": id,
                "userName": name,
                "userPassword": password,
                "userEmail": emailId
              })
                .then(res=>res.data).catch(err=>console.log(err));
            alert("Registration Successful!");
            navigate("/LoginUser");
        }
    }

    return(
        <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>
                <label>EmailId</label><br/>
                <input type="text" placeholder="Enter EmailId" value={emailId} onChange={(e)=>{setEmailId(e.target.value)}} required></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Register</button>
            </form>
            <p className="para1" > Already have an Account? <NavLink className="link" to="/LoginUser">Login</NavLink></p>
        </div>
    )
}
export default RegisterUser;