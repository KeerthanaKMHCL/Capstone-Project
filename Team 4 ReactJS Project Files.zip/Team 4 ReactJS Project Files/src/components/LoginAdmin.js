/*
Author: Mounisha
Date: 21/01/2023
*/

import { useState } from "react"
import { useNavigate } from "react-router-dom";

function LoginAdmin(){

    const[emailId,setEmailId]=useState("");
    const[password,setPassword]=useState("");
    const navigate=useNavigate();

    const clickEv=(e)=>{
        e.preventDefault();
            if(emailId==="capstone2023team4@gmail.com" && password==="Team4KLMY"){
                alert("Login Successful!");
                navigate("/AdminDashboard");
            }else{
                alert("Invalid Login Credentials")
                navigate("/LoginAdmin");
            }
        }

    return(
        <div className="card">
            <form>
                <label>Email</label><br/>
                <input type="text" placeholder="Enter Email" onChange={(e)=>{setEmailId(e.target.value)}} value={emailId}></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" onChange={(e)=>{setPassword(e.target.value)}} value={password} ></input><br/>
                <button onClick={clickEv}>Login</button>
            </form>
        </div>
        

    )
}
export default LoginAdmin;