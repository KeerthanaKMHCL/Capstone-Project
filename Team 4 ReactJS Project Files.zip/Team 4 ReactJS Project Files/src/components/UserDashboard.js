import React from 'react'
import { MDBCol, MDBIcon } from "mdbreact";
import { useNavigate } from "react-router-dom";
import Property from "../components/Properties"
import UserPropertyOps from "../services/UserPropertyOperations"

function UserDashboard() {

    const navigate=useNavigate();

    const logout=(e)=>{
        e.preventDefault();
        alert("Logout Successful!");
        navigate("/")
    }
    const reserve=(e)=>{
      e.preventDefault();
      navigate("/Reserve")
  }
  const review=(e)=>{
    e.preventDefault();
    navigate("/UserReview")
}

  return (
    <div>
      <div className='dash'>    
            <p>User Dashboard</p>
        </div><br></br>
    <MDBCol md="6">
      <div className="input-group md-form form-sm form-1 pl-0">
        <div className="input-group-prepend">
          <span className="input-group-text purple lighten-3" id="basic-text1">
            <MDBIcon className="text-white" icon="search"/>
          </span>
        </div>
        <input
          className="form-control my-0 py-1"
          type="text"
          placeholder="Search by Property Id"
          aria-label="Search"
        />
      </div>
      </MDBCol>
      <br></br>
      <UserPropertyOps/>
      <Property/>
      <br></br>
      <div className='card'>
            <button onClick={reserve}>Reserve</button>
            <button onClick={logout}>Logout</button>
            <button onClick={review}>Review</button>
        </div>
        </div>
  )
}

export default UserDashboard