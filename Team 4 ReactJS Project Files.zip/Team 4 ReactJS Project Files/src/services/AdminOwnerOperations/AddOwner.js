import React from 'react'
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import axios from 'axios'

function AddOwner() {

  const[id,setId]=useState(0);
  const[name,setName]=useState("");
  const[emailId,setEmailId]=useState("");
  const[password,setPassword]=useState("");
  const[owners,setOwners]=useState([]);
  const navigate=useNavigate();


  useEffect(()=>{
    axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(res=>setOwners(res.data)).catch(err=>console.log(err));
  },[]);
  const ClickEv=(e)=>{
    e.preventDefault();
    let count=0;
    for(let i=0;i<owners.length;i++){
        if(owners[i].ownerEmail===emailId || owners[i].ownerId===id){
            setId(e.target.value)
            count++;
        }
    }
    if(count>0){
        alert("Owner already exists!!!");
    }
    else{axios.post("http://localhost:8080/api/admin/owner/addOwner",{
                "ownerEmail": emailId,
                "ownerName": name,
                "ownerPassword": password
            }
            ).then(res=>res.data).catch(err=>console.log(err));
            alert("Owner Successfully Added!");
            navigate("/AdminDashboard");
          }
  }

  return (
    <div className="card">
            <form>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>

                <label>EmailId</label><br/>
                <input type="email" placeholder="Enter EmailId" value={emailId} onChange={(e)=>{setEmailId(e.target.value)}} required></input><br/>

                <label>Password</label><br/>
                <input type="password" placeholder="Enter Password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required></input><br/>

                <button onClick={ClickEv}>Add Owner</button>
            </form>
        </div>
  )
}

export default AddOwner