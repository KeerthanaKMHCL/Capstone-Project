import React from 'react'
import { useNavigate } from "react-router-dom";
import './Home.css'

function AdminDashboard() {

    const navigate=useNavigate();

    const add=(e)=>{
        e.preventDefault();
           {
                navigate("/AddOwner");
            }
        }

    const delt=(e)=>{
        e.preventDefault();
            {
                navigate("/DeleteOwner");
            }
        }

    const update=(e)=>{
        e.preventDefault();
            {
                navigate("/UpdateOwner");
            }
        }

    const list=(e)=>{
        e.preventDefault();
            {
                navigate("/ListAllOwners");
            }
        }

        const logout=(e)=>{
            e.preventDefault();
            alert("Logout Successful!");
            navigate("/")
        }

  return (
    <div>
        <div className='dash'>    
            <p>Admin Dashboard</p>
        </div>
        <ul className='ulist'>
            <button onClick={add}>Add Owner</button>
            <button onClick={delt}>Delete Owner</button>
            <button onClick={update}>Update Owner</button>
            <button onClick={list}>List All Owners</button>
        </ul>
        <div className='card'>
            <button onClick={logout}>Logout</button>
        </div>
    </div>
  )
}

export default AdminDashboard