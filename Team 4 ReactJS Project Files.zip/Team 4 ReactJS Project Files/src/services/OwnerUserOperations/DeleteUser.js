import React from 'react'
import { useEffect, useState } from "react"
import axios from 'axios'
import { useNavigate } from "react-router-dom"

function DeleteUser() {

    const[id,setId]=useState(0);
    const[users,setUsers]=useState([]);
    const navigate=useNavigate();

    useEffect(()=>{
        axios.get("http://localhost:8080/api/owner/user/getAllUsers").then(res=>setUsers(res.data)).catch(err=>console.log(err));
      },[]);
      const ClickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<users.length;i++){
            if(users[i].userId===id){
                count++;
            }
        }
        if(count>0){
            axios.delete("http://localhost:8080/api/owner/user/deleteUserById/"+id)
            .then(res=>res.data).catch(err=>console.log(err));
                alert("User Successfully Deleted!");
                navigate("/OwnerDashboard");
        }
        else{
            alert("User does not exist");
            }
      }
  return (
    <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Delete User</button>
            </form>
        </div>
  )
}

export default DeleteUser