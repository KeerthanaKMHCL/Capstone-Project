import { useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";


function UserReview(){
    const[id,setId]=useState(0);
    const[name,setName]=useState("");
    const[comment,setComment]=useState("");
    const navigate=useNavigate();
    
    const ClickEv=(e)=>{
        e.preventDefault();
        axios.post("http://localhost:8484/api/userReview/addReview",{
             "userId": id,
             "userName": name,
             "comment": comment
        })
            .then(res=>res.data).catch(err=>console.log(err));
            alert("Review Posted Successfully!");
            navigate("/UserReview");
    }

    return(
        <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>
                <label>Comment</label><br/>
                <input type="text" placeholder="Enter Comment/ Ask a question" value={comment} onChange={(e)=>{setComment(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Post Review</button>
            </form>
            <p className="para1" > Do you wish to Logout? <NavLink className="link" to="/Logout">Click Here</NavLink></p>
        </div>
    )
}
export default UserReview;