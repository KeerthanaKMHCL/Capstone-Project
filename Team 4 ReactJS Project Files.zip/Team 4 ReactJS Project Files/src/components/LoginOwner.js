/*
Author: Mounisha
Date: 19/01/2023
*/

import axios from "axios";
import { useEffect, useState } from "react"
import { NavLink, useNavigate } from "react-router-dom";

function LoginOwner()
{
    const[emailId,setEmailId]=useState("");
    const[password,setPassword]=useState("");
    const[owners,setOwners]=useState([]);
    const navigate=useNavigate();
    useEffect(()=>{
        axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(resp=>setOwners(resp.data)).catch(err=>console.log(err));
    },[])
    const clickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<owners.length;i++){
            if(owners[i].ownerEmail===emailId && owners[i].ownerPassword===password){
                localStorage.setItem("Info",JSON.stringify(owners[i]));
                count++;
            }
        }
        if(count>0){
            alert("Login Successful!");
            navigate("/OwnerDashboard");

        }
        else{
            alert("Invalid Login Credentials");
            navigate("/LoginOwner");
        }
    }

    return(
        <div className="card">
            <form>
                <label>Email</label><br/>
                <input type="text" placeholder="Enter Email" onChange={(e)=>{setEmailId(e.target.value)}} value={emailId}></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" onChange={(e)=>{setPassword(e.target.value)}} value={password} ></input><br/>
                <button onClick={clickEv}>Login</button>
            </form>
            <p className="para">New User? <NavLink className="link" to="/RegisterOwner">Sign Up</NavLink></p>
        </div>
    )
}
export default LoginOwner;