/*
Author: Keerthana
Date: 19/01/2023
*/

import './App.css';
import { Route, Routes } from 'react-router-dom';
import Home from './components/Home';

import RegisterUser from './components/RegisterUser';
import RegisterOwner from './components/RegisterOwner';

import AdminDashboard from './components/AdminDashboard';
import OwnerDashboard from './components/OwnerDashboard';
import UserDashboard from './components/UserDashboard';

import LoginOwner from './components/LoginOwner';
import LoginAdmin from './components/LoginAdmin';
import LoginUser from './components/LoginUser';

import AddOwner from './services/AdminOwnerOperations/AddOwner'
import DeleteOwner from './services/AdminOwnerOperations/DeleteOwner'
import UpdateOwner from './services/AdminOwnerOperations/UpdateOwner'
import ListAllOwners from './services/AdminOwnerOperations/ListAllOwners'

import AddProperty from './services/OwnerPropertyOperations/AddProperty'
import DeleteProperty from './services/OwnerPropertyOperations/DeleteProperty'
import UpdateProperty from './services/OwnerPropertyOperations/UpdateProperty'
import ListAllProperties from './services/OwnerPropertyOperations/ListAllProperties'

import AddUser from './services/OwnerUserOperations/AddUser'
import DeleteUser from './services/OwnerUserOperations/DeleteUser'
import UpdateUser from './services/OwnerUserOperations/UpdateUser'
import ListAllUsers from './services/OwnerUserOperations/ListAllUsers'

import Properties from './components/Properties';
import Propertiess from './components/Propertiess';

import Reserve from './services/UserReservationOperations'
import UserReview from './services/UserReviewOperations'
import Review from './components/Rating';
import Logout from './components/Logout';

function App() {
  return (
    <div className="App">
      <Routes>
      <Route path="/" element={<Home></Home>}></Route>

        <Route path="/RegisterOwner" element={<RegisterOwner></RegisterOwner>}></Route>
        <Route path="/RegisterUser" element={<RegisterUser></RegisterUser>}></Route>

        <Route path="/LoginAdmin" element={<LoginAdmin></LoginAdmin>}></Route>
        <Route path="/LoginOwner" element={<LoginOwner></LoginOwner>}></Route>
        <Route path="/LoginUser" element={<LoginUser></LoginUser>}></Route>

        <Route path="/AdminDashboard" element={<AdminDashboard></AdminDashboard>}></Route>
        <Route path="/OwnerDashboard" element={<OwnerDashboard></OwnerDashboard>}></Route>
        <Route path="/UserDashboard" element={<UserDashboard></UserDashboard>}></Route>

        <Route path="/AddOwner" element={<AddOwner></AddOwner>}></Route>
        <Route path="/DeleteOwner" element={<DeleteOwner></DeleteOwner>}></Route>
        <Route path="/UpdateOwner" element={<UpdateOwner></UpdateOwner>}></Route>
        <Route path="/ListAllOwners" element={<ListAllOwners></ListAllOwners>}></Route>

        <Route path="/AddUser" element={<AddUser></AddUser>}></Route>
        <Route path="/DeleteUser" element={<DeleteUser></DeleteUser>}></Route>
        <Route path="/UpdateUser" element={<UpdateUser></UpdateUser>}></Route>
        <Route path="/ListAllUsers" element={<ListAllUsers></ListAllUsers>}></Route>

        <Route path="/AddProperty" element={<AddProperty></AddProperty>}></Route>
        <Route path="/DeleteProperty" element={<DeleteProperty></DeleteProperty>}></Route>
        <Route path="/UpdateProperty" element={<UpdateProperty></UpdateProperty>}></Route>
        <Route path="/ListAllProperties" element={<ListAllProperties></ListAllProperties>}></Route>

        <Route path="/Properties" element={<Properties></Properties>}></Route>
        <Route path="/Propertiess" element={<Propertiess></Propertiess>}></Route>

        <Route path="/Reserve" element={<Reserve></Reserve>}></Route>
        <Route path="/Review" element={<Review></Review>}></Route>
        <Route path="/UserReview" element={<UserReview></UserReview>}></Route>
        <Route path="/Logout" element={<Logout></Logout>}></Route>
      </Routes>
    </div>
  );
}

export default App;
