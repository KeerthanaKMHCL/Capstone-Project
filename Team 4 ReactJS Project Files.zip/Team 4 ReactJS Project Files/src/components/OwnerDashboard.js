import React from 'react'
import { useNavigate } from "react-router-dom";
import './Home.css'

function OwnerDashboard() {

    const navigate=useNavigate();

    const add1=(e)=>{
        e.preventDefault();
           {
                navigate("/AddUser");
            }
        }

        const add2=(e)=>{
            e.preventDefault();
               {
                    navigate("/AddProperty");
                }
            }

    const delt1=(e)=>{
        e.preventDefault();
            {
                navigate("/DeleteUser");
            }
        }

        const delt2=(e)=>{
            e.preventDefault();
                {
                    navigate("/DeleteProperty");
                }
            }
    const update1=(e)=>{
        e.preventDefault();
            {
                navigate("/UpdateUser");
            }
        }
        const update2=(e)=>{
            e.preventDefault();
                {
                    navigate("/UpdateProperty");
                }
            }

    const list1=(e)=>{
        e.preventDefault();
            {
                navigate("/ListAllUsers");
            }
        }
        const list2=(e)=>{
            e.preventDefault();
                {
                    navigate("/ListAllProperties");
                }
            }
            const logout=(e)=>{
                e.preventDefault();
                alert("Logout Successful!");
                navigate("/")
            }

  return (
    <div>
        <div className='dash'>    
            <p>Owner Dashboard</p>
        </div>
        <ul className='ulist'>
            <button onClick={add1}>Add User</button>
            <button onClick={delt1}>Delete User</button>
            <button onClick={update1}>Update User</button>
            <button onClick={list1}>List All Users</button>
        </ul><br></br>
        <ul className='ulist1'>
            <button onClick={add2}>Add Property</button>
            <button onClick={delt2}>Delete Property</button>
            <button onClick={update2}>Update Property</button>
            <button onClick={list2}>List All Properties</button>
        </ul><br></br>
        <div className='card'>
            <button onClick={logout}>Logout</button>
        </div>
    </div>
  )
}

export default OwnerDashboard