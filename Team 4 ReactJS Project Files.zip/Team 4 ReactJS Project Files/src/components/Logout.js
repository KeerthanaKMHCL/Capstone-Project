/*
Author: Mounisha
Date: 19/01/2023
*/

import { useNavigate } from "react-router-dom";

function Logout(){
    
    const nav=useNavigate();

    const ClickEvent=(e)=>{
        e.preventDefault();
        alert("Logout Successful!");
        nav("/")
    }

    const ClickEv=(e)=>{
        e.preventDefault();
        nav("/UserReview");
    }

    return(
        <div>
         {/* <li><NavLink to="/Logout"><button>Logout</button></NavLink></li> */}
        <div className="card">
        <h1>Are You Sure?</h1>
        <button onClick={ClickEv}>No</button>
        <button onClick={ClickEvent}>Yes</button>
    </div>
    </div>)
}
export default Logout;