/*
Author: Likitha
Date: 19/01/2023
*/

import React from 'react'

function Properties() {
  return (
  <>
  <div class="row">
    <div class="col-sm-6 mb-6 mb-sm-0">
    <div class="cardpic">
      <div>
        <h4>#1</h4>
        <img src="properties/property1/p1.jfif" className="card-img-top" alt="Property1" />
        <p className="card-text">Id: 01<br></br>Owner Id : 01<br></br>Property Price: 25000<br></br>Property Rating: 5<br></br>Address: 1-2b, Kp colony<br></br>City:Downtown<br></br>Availability: Available <br></br>Property Type: Villa<br></br>Amenities: Sit Out, Garden Area, Badminton Court</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
    </div>


    <div class="col-sm-6">
    <div class="cardpic">
      <div>
        <h4>#2</h4>
        <img src="properties/property2/p1.jfif" className="card-img-top" alt="Property2" />
        <p className="card-text">Id: 02<br></br>Owner Id: 02<br></br>Property Price: 12000<br></br>Property Rating: 4<br></br>Address: 2-5b, Kp colony<br></br>City: Downtown<br></br>Availability: Available<br></br>Property Type: Apartment<br></br>Amenities: Balcony, Storage Room, Lift Backup</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
    </div>
</div>


<div class="row">
  <div class="col-sm-6 mb-6 mb-sm-0">
    <div class="cardpic">
      <div class="card-body">
        <h4>#3</h4>
        <img src="properties/property3/p1.jfif" className="card-img-top" alt="Property3" />
        <p className="card-text">Id: 03<br></br>Owner Id : 03<br></br>Property Price: 45000<br></br>Property Rating: 5<br></br>Address: 2b, Dan colony<br></br>City: Cable Park<br></br>Availability: Available<br></br>Property Type: Flat<br></br>Amenities: Gym, Garden, Party Hall</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>


  <div class="col-sm-6">
    <div class="cardpic">
      <div>
        <h4>#4</h4>
        <img src="properties/property4/p1.jfif" className="card-img-top" alt="Property4" />
        <p className="card-text">Id: 04<br></br>Owner Id : 04<br></br>Property Price: 17000<br></br>Property Rating: 4<br></br>Address: 69-3, Minet colony<br></br>City: Downtown<br></br>Availability: Available <br></br>Property Type: Apartment<br></br>Amenities: Balcony, Storage Room, Lift Backup</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-sm-6 mb-6 mb-sm-0">
    <div class="cardpic">
      <div>
        <h4>#5</h4>
        <img src="properties/property5/p1.jfif" className="card-img-top" alt="Property5" />
        <p className="card-text">Id: 05<br></br>Owner Id: 03<br></br>Property Price: 23000<br></br>Property Rating: 3<br></br>Address: 23-7, Brown colony<br></br>City: Micheal Town<br></br>Availability: Available <br></br>Property Type: Villa<br></br>Amenities: Sit Out, Garden Area, Badminton Court</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>


  <div class="col-sm-6">
    <div class="cardpic">
      <div>
        <h4>#6</h4>
        <img src="properties/property6/p1.jfif" className="card-img-top" alt="Property6" />
        <p className="card-text">Id: 06<br></br>Owner Id: 01<br></br>Property Price: 13000<br></br>Property Rating: 4<br></br>Address: 69-3, Hams colony<br></br>City: Breakstop<br></br>Availability: Available<br></br>Property Type: Apartment<br></br>Amenities: Balcony, Storage Room, Lift Backup</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-sm-6 mb-6 mb-sm-0">
    <div class="cardpic">
      <div>
        <h4>#7</h4>
        <img src="properties/property7/p1.jfif" className="card-img-top" alt="Property7" />
        <p className="card-text">Id: 07<br></br>Owner Id: 01<br></br>PropertyPrice: 20000<br></br>Property Rating: 5<br></br>Address: 15b,Santamonica street<br></br>City: Brikestone<br></br>Availability: Available<br></br>Property Type: Villa<br></br>Amenities: Sit Out, Garden Area, Badminton Court</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>


  <div class="col-sm-6">
  <div class="cardpic">
      <div>
        <h4>#8</h4>
        <img src="properties/property8/p1.jfif" className="card-img-top" alt="Property8" />
        <p className="card-text">Id: 08<br></br>Owner Id: 02<br></br>PropertyPrice: 13000<br></br>Property Rating: 4<br></br>Address: 69-3, Hams colony<br></br>City: Breakstop<br></br>Availability: Available<br></br>Property Type: Villa<br></br>Amenities: Sit Out, Garden Area, Badminton Court</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-sm-6 mb-6 mb-sm-0">
  <div class="cardpic">
      <div>
        <h4>#9</h4>
        <img src="properties/property9/p1.jfif" className="card-img-top" alt="Property9" />
        <p className="card-text">Id: 09<br></br>Owner Id: 03<br></br>PropertyPrice: 200000<br></br>Property Rating: 5<br></br>Address: 23b,Santamonica street<br></br>City: Brikestone<br></br>Availability: Available<br></br>Property Type: Flat<br></br>Amenities: Gym, Garden, Party Hall</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>


  <div class="col-sm-6">
    <div class="cardpic">
      <div>
        <h4>#10</h4>
        <img src="properties/property10/p1.jfif" className="card-img-top" alt="Property10" />
        <p className="card-text">Id: 10<br></br>Owner Id : 02<br></br>PropertyPrice: 46000<br></br>Property Rating: 4<br></br>Address: 45/b, Mid colony<br></br>City: Middle Street<br></br>Availability: Available <br></br>Property Type: Flat<br></br>Amenities: Gym, Garden, Party Hall</p>
        <a href="/Review" class="btn btn-primary">Review</a>
      </div>
    </div>
  </div>
</div>
    </>
  )
}

export default Properties
