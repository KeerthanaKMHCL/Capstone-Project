import React from 'react'
import { useEffect, useState } from "react"
import axios from 'axios'
import { useNavigate } from "react-router-dom"

function DeleteOwner() {

    const[id,setId]=useState(0);
    const[owners,setOwners]=useState([]);
    const navigate=useNavigate();

    useEffect(()=>{
        axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(res=>setOwners(res.data)).catch(err=>console.log(err));
      },[]);

      const ClickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<owners.length;i++){
            if(owners[i].ownerId===id){
                count++;
            }
        }
        if(count>0){
            axios.delete("http://localhost:8080/api/admin/owner/deleteOwnerById/14")
            .then(res=>res.data).catch(err=>console.log(err));
                alert("Owner Successfully Deleted!");
                navigate("/AdminDashboard");
        }
        else{
            alert("Owner does not exist");
            }
      }
  return (
    <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Delete Owner</button>
            </form>
        </div>
  )
}

export default DeleteOwner