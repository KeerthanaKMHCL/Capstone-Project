import React, { Component } from 'react'
import axios from 'axios'

class ListAllUsers extends Component {

state = {
    users: []
}

componentDidMount = () => {
    axios.get("http://localhost:8080/api/owner/user/getAllUsers").then(res => {
        const users = res.data;
        this.setState({users});
    }).catch(err=>console.log(err));
}

  render() {
    return (
      <div>
            <ul>{
                this.state.users.map(user =>
                                <div className='innerDiv'>
                                    <li>ID : {user.userId}</li>
                                    <li>Name : {user.userName}</li>
                                    <li>EmailID : {user.userEmail}</li>
                                    <li>Password : {user.userPassword}</li>
                                </div>
                    )}
            </ul>
      </div>
    )
  }
}

export default ListAllUsers