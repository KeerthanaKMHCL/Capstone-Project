/*
Author: Mounisha
Date: 21/01/2023
*/

import { useEffect, useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";

function RegisterOwner(){
    const[id,setId]=useState(0);
    const[name,setName]=useState("");
    const[emailId,setEmailId]=useState("");
    const[password,setPassword]=useState("");
    const[owners,setOwners]=useState([]);
    const navigate=useNavigate();
    
    useEffect(()=>{
        axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(res=>setOwners(res.data)).catch(err=>console.log(err));
    },[]);
    const ClickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<owners.length;i++){
            if(owners[i].ownerEmail===emailId){
                count++;
            }
        }
        if(count>0){
            alert("EmailId already exists!!!");
        }
        else{
            axios.post("http://localhost:8080/api/owner/register",{
                "ownerId": id,
                "ownerName": name,
                "ownerPassword": password,
                "ownerEmail": emailId
            }
            ).then(res=>res.data).catch(err=>console.log(err));
            alert("Registration Successful!");
            navigate("/LoginOwner");
        }
    }

    return(
        <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>
                <label>EmailId</label><br/>
                <input type="text" placeholder="Enter EmailId" value={emailId} onChange={(e)=>{setEmailId(e.target.value)}} required></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Register</button>
            </form>
            <p className="para1" > Already have an Account? <NavLink className="link" to="/LoginOwner">Login</NavLink></p>
        </div>
    )
}
export default RegisterOwner;