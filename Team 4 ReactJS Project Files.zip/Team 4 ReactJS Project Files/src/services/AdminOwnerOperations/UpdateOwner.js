import React from 'react'
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import axios from 'axios'

function UpdateOwner() {
  const[id,setId]=useState(0);
  const[name,setName]=useState("");
  const[emailId,setEmailId]=useState("");
  const[password,setPassword]=useState("");
  const[owners,setOwners]=useState([]);
  const navigate=useNavigate();


  useEffect(()=>{
    axios.get("http://localhost:8080/api/admin/owner/getAllOwners").then(res=>setOwners(res.data)).catch(err=>console.log(err));
  },[]);
  const ClickEv=(e)=>{
    e.preventDefault();
    let count=0;
    for(let i=0;i<owners.length;i++){
        if(owners[i].ownerEmail===emailId || owners[i].ownerId===id){
            count++;
        }
    }
    if(count>0){
        axios.put("http://localhost:8080/api/admin/owner/updateOwner/14",{
                "ownerId": id,
                "ownerName": name,
                "ownerPassword": password,
                "ownerEmail": emailId
            }
            ).then(res=>
              {const a = res.data
              console.log(a)}).catch(err=>console.log(err));
            alert("Owner Successfully Updated!");
            navigate("/AdminDashboard");
    }
    else{
          alert("Owner does not exist...");
          }
  }

  return (
    <div className="card">
            <form>
                <label>Id</label><br/>
                <input type="number" placeholder="Enter Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Name</label><br/>
                <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>{setName(e.target.value)}} required></input><br/>
                <label>EmailId</label><br/>
                <input type="email" placeholder="Enter EmailId" value={emailId} onChange={(e)=>{setEmailId(e.target.value)}} required></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Update Owner</button>
            </form>
        </div>
  )
}

export default UpdateOwner