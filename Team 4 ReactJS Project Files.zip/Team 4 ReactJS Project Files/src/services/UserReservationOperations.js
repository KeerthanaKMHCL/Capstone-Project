import { useEffect, useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";

function UserReservationOperations() {
    const[id,setId]=useState(0);
    const[pid,setPid]=useState(0);
    const[chkin,setChkin]=useState("2023-01-22T21:35:22.630Z");
    const[chkout,setChkout]=useState("2023-01-22T21:35:22.630Z");
    const[reservations,setReservations]=useState([]);
    const navigate=useNavigate();
    
    useEffect(()=>{
        axios.get("http://localhost:8080/api/user/reserved/getAllReservations").then(res=>setReservations(res.data)).catch(err=>console.log(err));
    },[]);
    const ClickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<reservations.length;i++){
            if(reservations[i].propertyId===pid){
                count++;
            }
        }
        if(count>0){
            alert("Property already Reserved!!");
        }
        else{
            axios.post("http://localhost:8080/api/user/reserved/addToReserved",{
                "userId": id,
                "propertyId": pid,
                "checkIn": chkin,
                "checkOut": chkout
              })
                .then(res=>res.data).catch(err=>console.log(err));
            alert("Reservation Successful!");
            axios.patch("http://localhost:8080/api/owner/property/updateProperty",{
                "propertyId": pid,
                "availability": "Reserved"
            })
            navigate("/UserDashboard");
        }
    }

    return(
        <div className="card">
            <form>
                <label>User Id</label><br/>
                <input type="number" placeholder="Enter your Id" value={id} onChange={(e)=>{setId(e.target.value)}} required></input><br/>
                <label>Property Id</label><br/>
                <input type="number" placeholder="Enter property Id" value={pid} onChange={(e)=>{setPid(e.target.value)}} required></input><br/>
                <label>Check-In Date</label><br/>
                <input type="datetime-local" placeholder="Enter Check-in date" value={chkin} onChange={(e)=>{setChkin(e.target.value)}} required></input><br/>
                <label>Check-Out Date</label><br/>
                <input type="datetime-local" placeholder="Enter Check-out date" value={chkout} onChange={(e)=>{setChkout(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Reserve</button>
            </form>
            <p className="para1" > I do not wish to Reserve <NavLink className="link" to="/UserDashboard">Go back to Dashboard</NavLink></p>
        </div>
    )
}

export default UserReservationOperations