package com.hcl.rentaplace.exception;

/*
 * Author: Keerthana
 * Date: 17/01/2023
 */

public class OwnerNotFoundException extends Exception{

}
