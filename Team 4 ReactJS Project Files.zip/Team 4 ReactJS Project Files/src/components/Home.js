/*
Author: Mounisha
Date: 19/01/2023
*/

import { NavLink } from "react-router-dom";
import Carousel from "react-bootstrap/Carousel";
import './Home.css';

function Home(){

    return(
        <>
        <div className="bg">
            <p>Rent a Place</p>
        </div>
        <Carousel>
            <Carousel.Item interval={3000}>
                <img
                    className="d-block w-100"
                    src="slideshow-home/slide1.jfif"
                    alt="First slide"
                />
                <Carousel.Caption>
                    <h4>Are you looking for a Place to Rent?</h4>
                </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item interval={3000}>
                <img
                    className="d-block w-100"
                    src="slideshow-home/slide2.jfif"
                    alt="Second slide"
                />
                <Carousel.Caption>
                    <h4>Then you are at the right place!</h4>
                </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item interval={4000}>
                <img
                    className="d-block w-100"
                     src="slideshow-home/slide3.jfif"
                    alt="Third slide"
                 />
                <Carousel.Caption>
                    <h4>Our Website Helps you to book or rent places according to your choice of dates and requirements!</h4>
                </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item interval={4000}>
                <img
                    className="d-block w-100"
                    src="slideshow-home/slide4.jfif"
                    alt="Fourth slide"
                />
            <Carousel.Caption>
                <h4>Hope you spend a quality time with your loved ones, at your place of choice!!</h4>
            </Carousel.Caption>
        </Carousel.Item>
        </Carousel>
        <br></br>
        <div className="nb1">
            <NavLink to="/LoginAdmin"><button>Login as Admin</button></NavLink>
            <NavLink to="/LoginOwner"><button>Login as Owner</button></NavLink>
            <NavLink to="/LoginUser"><button>Login as User</button></NavLink>
        </div>
    </>
    )
}
export default Home;