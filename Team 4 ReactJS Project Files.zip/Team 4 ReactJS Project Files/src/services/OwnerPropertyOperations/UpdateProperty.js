import React from 'react'
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import axios from 'axios'

function AddProperty() {

  const[pid,setPid]=useState(0);
  const[address,setAddress]=useState("");
  const[amenities,setAmenities]=useState("");
  const[availability,setAvailability]=useState("");
  const[city,setCity]=useState("");
  const[oid,setOid]=useState(0);
  const[type,setType]=useState("");
  const[rating,setRating]=useState(0.0);
  const[properties,setProperties]=useState([]);
  const navigate=useNavigate();


  useEffect(()=>{
    axios.get("http://localhost:8080/api/owner/property/propertiesList").then(res=>setProperties(res.data)).catch(err=>console.log(err));
  },[]);
  const ClickEv=(e)=>{
    e.preventDefault();
    let count=0;
    for(let i=0;i<properties.length;i++){
        if(properties[i].propertyId===pid){
            count++;
        }
    }
    if(count>0){
        axios.patch("http://localhost:8080/api/owner/property/addProperty"+pid,{
                "address": address,
                "amenities": amenities,
                "availability": availability,
                "city":city,
                "ownerId":oid,
                "propertyType":type,
                "rating":rating
            }
            ).then(res=>res.data).catch(err=>console.log(err));
            alert("Property Successfully Updated!");
            navigate("/OwnerDashboard");
    }
    else{
        alert("Property does not exist");
          }
  }

  return (
    <div className="card">
            <form>
                <label>Property ID</label><br/>
                <input type="number" placeholder="Enter Property Id" value={pid} onChange={(e)=>{setPid(e.target.value)}} required></input><br/>
                <label>Property Address</label><br/>
                <input type="text" placeholder="Enter Property Address" value={address} onChange={(e)=>{setAddress(e.target.value)}} required></input><br/>
                <label>Amenities</label><br/>
                <input type="text" placeholder="Enter Amenities" value={amenities} onChange={(e)=>{setAmenities(e.target.value)}} required></input><br/>
                <label>Availability</label><br/>
                <input type="text" placeholder="Enter Available or Reserved" value={availability} onChange={(e)=>{setAvailability(e.target.value)}} required></input><br/>
                <label>City</label><br/>
                <input type="text" placeholder="Enter City" value={city} onChange={(e)=>{setCity(e.target.value)}} required></input><br/>
                <label>Owner ID</label><br/>
                <input type="number" placeholder="Enter your Id" value={oid} onChange={(e)=>{setOid(e.target.value)}} required></input><br/>
                <label>Property Type</label><br/>
                <input type="text" placeholder="Enter Flat/Villa/Apartment" value={type} onChange={(e)=>{setType(e.target.value)}} required></input><br/>
                <label>Property Rating</label><br/>
                <input type="number" placeholder="Enter Rating" value={rating} onChange={(e)=>{setRating(e.target.value)}} required></input><br/>
                <button onClick={ClickEv}>Update Property</button>
            </form>
        </div>
  )
}

export default AddProperty