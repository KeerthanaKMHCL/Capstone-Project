/*
Author: Mounisha
Date: 21/01/2023
*/

import axios from "axios";
import { useEffect, useState } from "react"
import { NavLink, useNavigate } from "react-router-dom";

function LoginUser()
{
    const[emailId,setEmailId]=useState("");
    const[password,setPassword]=useState("");
    const[users,setUsers]=useState([]);
    const navigate=useNavigate();
    useEffect(()=>{
        axios.get("http://localhost:8080/api/owner/user/getAllUsers").then(resp=>setUsers(resp.data)).catch(err=>console.log(err));
    },[])
    const clickEv=(e)=>{
        e.preventDefault();
        let count=0;
        for(let i=0;i<users.length;i++){
            if(users[i].userEmail===emailId && users[i].userPassword===password){
                localStorage.setItem("Info",JSON.stringify(users[i]));
                count++;
            }
        }
        if(count>0){
            alert("Login Successful!");
            navigate("/UserDashboard");
        }
        else{
            alert("Invalid Login Credentials");
            navigate("/LoginUser");
        }
    }

    return(
        <div className="card">
            <form>
                <label>Email</label><br/>
                <input type="text" placeholder="Enter Email" onChange={(e)=>{setEmailId(e.target.value)}} value={emailId}></input><br/>
                <label>Password</label><br/>
                <input type="password" placeholder="Enter password" onChange={(e)=>{setPassword(e.target.value)}} value={password} ></input><br/>
                <button onClick={clickEv}>Login</button>
            </form>
            <p className="para">New User? <NavLink className="link" to="/RegisterUser">Sign Up</NavLink></p>
        </div>
        

    )
}
export default LoginUser;