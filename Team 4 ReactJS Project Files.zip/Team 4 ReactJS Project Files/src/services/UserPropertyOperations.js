import React, { Component } from 'react'
import axios from 'axios'

export class UserPropertyOperations extends Component {

    state = {
        properties: [],
        c:1
    }
    
    componentDidMount = () => {
        axios.get("http://localhost:8080/api/user/property/getAllProperties").then(res => {
            const properties = res.data;
            this.setState({properties});
        }).catch(err=>console.log(err));
    }

  render() {
    return (
      <div>
        <ul>{
                this.state.properties.map(property =>
                                <div className='innerDiv'>
                                    <img src={'../../public/properties/property' +this.state.c+ '/p' +this.state.c+ '.jfif'} alt='prop'/>
                                    <li>Property Id : {property.propertyId}</li>
                                    <li>Address : {property.address}</li>
                                    <li>Amenities : {property.amenities}</li>
                                    <li>Availability : {property.availability}</li>
                                    <li>City : {property.city}</li>
                                    <li>Owner Id : {property.ownerId}</li>
                                    <li>Type of Property : {property.propertyType}</li>
                                    <li>Property Rating : {property.rating}</li>
                                </div>
                    )}
            </ul>
      </div>
    )
  }
}

export default UserPropertyOperations