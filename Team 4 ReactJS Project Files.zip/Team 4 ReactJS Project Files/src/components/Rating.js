/*
Author: Yashwanth
Date: 19/01/2023
*/

import React, { useState } from "react";
import { FaStar } from "react-icons/fa";
import { Container, Radio, Rating } from "./RatingStyles";
import { useNavigate } from "react-router-dom";

const Rate = () => {
const [rate, setRate] = useState(0);

const nav = useNavigate();

const logout=(e)=>{
	e.preventDefault();
	alert("Logout Successful!");
	nav("/");
}

return (
	<div>
	<Container>
	{[...Array(5)].map((item, index) => {
		const givenRating = index + 1;
		return (
		<label>
			<Radio
			type="radio"
			value={givenRating}
			onClick={() => {
				setRate(givenRating);
				alert(`Are you sure you want to give ${givenRating} stars ?`);
			}}
			/>
			<Rating>
			<FaStar
				color={
				givenRating < rate || givenRating === rate
					? "000"
					: "rgb(192,192,192)"
				}
			/>
			</Rating>
		</label>
		);
	})}
	</Container>
	<div className="card">
	<button onClick={logout}>Logout</button>
	</div>
	</div>
);
};

export default Rate;
